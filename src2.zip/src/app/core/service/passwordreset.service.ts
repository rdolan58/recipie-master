import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class PasswordResetService {
  private apiBaseUrl = 'http://127.0.0.1:8000/api'; // Update with your backend URL

  constructor(private http: HttpClient) {}

  // Send password reset email
  sendResetEmail(email: string): Observable<any> {
    return this.http.post(`${this.apiBaseUrl}/password-reset/`, { email });
  }

  // Reset password using token
  resetPassword(token: string, password: string): Observable<any> {
    return this.http.post(`${this.apiBaseUrl}/reset-password/${token}/`, { password });
  }
}