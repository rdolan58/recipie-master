// import { Injectable } from '@angular/core';
// import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

// import { AuthService } from '../service/auth.service';

// @Injectable({
//   providedIn: 'root',
// })
// export class AuthGuard  {
//   constructor(private authService: AuthService, private router: Router) {}

//   canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
//     if (this.authService.currentUserValue) {
//       return true;
//     }
//     this.router.navigate(['/authentication/signin']);
//     return false;
//   }
// }
import { Injectable } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../service/auth.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const publicRoutes = ['/authentication/signin', '/authentication/signup', '/authentication/forgot', '/authentication/reset']; // Add public routes here

    if (publicRoutes.some((url) => state.url.startsWith(url))) {
      // Allow access to public routes
      return true;
    }

    if (this.authService.currentUserValue) {
      // User is authenticated
      return true;
    }

    // Redirect to signin for private routes
    this.router.navigate(['/authentication/signin']);
    return false;
  }
}
