import { Route } from '@angular/router';
import { AdvanceTableComponent } from './advance-table.component';

export const ADVANCE_TABLE_ROUTE: Route[] = [
  {
    path: '',
    component: AdvanceTableComponent
  }
];

